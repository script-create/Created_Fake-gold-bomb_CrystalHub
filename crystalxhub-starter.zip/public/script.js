const button = document.querySelector("#downloadBtn");
const keyInput = document.querySelector("#accessKey");
const result = document.querySelector("#result");

button.addEventListener("click", async () => {
  button.disabled = true;
  result.textContent = "Checking access…";

  try {
    const response = await fetch("/api/access", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fileId: "demo", key: keyInput.value.trim() })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Access denied");

    const blob = new Blob([data.content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = data.name;
    link.click();
    URL.revokeObjectURL(url);
    result.textContent = "Access granted. Download started.";
  } catch (error) {
    result.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});