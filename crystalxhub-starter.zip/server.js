import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);
const adminToken = process.env.ADMIN_TOKEN;

if (!adminToken || adminToken.length < 24) {
  console.error("Set ADMIN_TOKEN to a long random secret in .env");
  process.exit(1);
}

app.use(helmet());
app.use(express.json({ limit: "32kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 60 }));
app.use(express.static(path.join(__dirname, "public")));

const files = new Map([
  ["demo", {
    id: "demo",
    name: "CrystalXHub-demo.lua",
    version: "1.0.0",
    content: "-- Demo placeholder. Add your own permitted file on the server.",
    public: false,
    requiredKey: true
  }]
]);

const keys = new Map([
  ["DEMO-KEY-CHANGE-ME", { active: true, expiresAt: null, uses: 0, maxUses: 10 }]
]);

function adminOnly(req, res, next) {
  if (req.get("x-admin-token") !== adminToken) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

function validKey(value) {
  const record = keys.get(String(value || ""));
  if (!record || !record.active) return false;
  if (record.expiresAt && Date.now() > record.expiresAt) return false;
  if (record.maxUses !== null && record.uses >= record.maxUses) return false;
  return true;
}

app.get("/api/files", (_req, res) => {
  res.json([...files.values()].map(({ content, ...meta }) => meta));
});

app.post("/api/access", (req, res) => {
  const { fileId, key } = req.body || {};
  const file = files.get(fileId);
  if (!file) return res.status(404).json({ error: "File not found" });

  const publicAllowed = process.env.PUBLIC_DOWNLOAD_ENABLED === "true";
  if (!file.public && !publicAllowed && !validKey(key)) {
    return res.status(403).json({ error: "Valid access key required" });
  }

  if (key && validKey(key)) keys.get(key).uses += 1;

  // Demo response: in production, issue a short-lived signed URL instead.
  res.json({
    fileId: file.id,
    name: file.name,
    version: file.version,
    content: file.content
  });
});

app.post("/api/admin/keys", adminOnly, (req, res) => {
  const maxUses = Number.isInteger(req.body?.maxUses) ? req.body.maxUses : 1;
  const key = crypto.randomBytes(18).toString("base64url");
  keys.set(key, { active: true, expiresAt: null, uses: 0, maxUses });
  res.status(201).json({ key, maxUses });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(port, () => {
  console.log(`CrystalXHub running on http://localhost:${port}`);
});